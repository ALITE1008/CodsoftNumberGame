package guessnum.org;

import java.util.Random;
import java.util.Scanner;

class GenrateNumber {
    Random R1 = new Random();
    public int GiveNumber() {
        int num = R1.nextInt(1, 100);
        return num;
    }

}

class GuessNumer {
    GenrateNumber N1 = new GenrateNumber();
    final int x = N1.GiveNumber();

    public int feedback(int usernum) {
        int flag = 0;

        if (x == usernum) {
            System.out.println("You have Gussed the correct Number");
            flag = 1;
        } else if (usernum > x) {
            System.out.println("The Number you have Enter IS Higer than Our Number ");
            flag = 2;
        } else if (usernum < x) {
            System.out.println("The Number you have Enter IS lower than Our Number ");
            flag = 3;
        }

        return flag;

    }
}

public class Tester {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int x = 1;
        while (x == 1) {

            System.out.println("You have Only 10 Chance");
            System.out.println("Enter Your Number between 1-100");
            GuessNumer Gn = new GuessNumer();
            for (int i = 0; i <= 10; i++) {
                System.out.println("Number of Your Choices You Used:" + i);
                int num = sc.nextInt();
                int xp = Gn.feedback(num);

                if (xp == 1) {
                    break;
                }
            }

            System.out.println("1-To play Again \n2-Exit");
            int ch = sc.nextInt();
            if (ch == 2) {
                x = 0;
            }

        }

        System.out.println("Thank You for playing");

    }
}
